#include <iostream>

using namespace std;

int main(){
    int a=1, b; cin >> a;
    while(a < 10)
    {
     a++;
     cout << a << endl;
     if( a%10 == 0)
     {
         cout << 5 << endl;
     }

    }

    return 0;
}
