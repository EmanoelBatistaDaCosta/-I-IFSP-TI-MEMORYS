#include <iostream>
//ajuda do meu aigo Raul czar
using namespace std;

int main() {
    int totalAlunos, capacidadeOnibus, alunosPorViagem; cin >> totalAlunos >> capacidadeOnibus;

    int viagensCompletas = totalAlunos / capacidadeOnibus;

    int alunosUltimaViagem = totalAlunos % capacidadeOnibus;

    for (int i = 1; i <= viagensCompletas; i++) {
        cout << capacidadeOnibus << endl;
    }
    if (alunosUltimaViagem > 0) {
        cout << alunosUltimaViagem << endl;
    }

    return 0;
}
