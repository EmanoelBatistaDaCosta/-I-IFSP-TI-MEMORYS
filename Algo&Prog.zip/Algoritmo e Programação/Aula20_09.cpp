#include <iostream>
#include <iomanip>
#include <algorithm>

using namespace std;

int main(){
    int id;
    string nom;
    float alt;

    cin >> id;
    cin.ignore();
    getline(cin,nom);
    cin >> alt;

    cin.ignore();

    cout << nom << " tem " << id << " anos e mede " << alt << " de altura." << endl;

 return 0;

}
