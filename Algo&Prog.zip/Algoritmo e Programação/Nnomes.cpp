#include <bits/stdc++.h>

using namespace std;

int main(){
    vector <string> lista;
    string nome;

    while(cin>>nome)
    {
        lista.push_back(nome);
    }

 return 0;
}
