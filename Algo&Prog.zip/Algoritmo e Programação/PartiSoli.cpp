#include <iostream>

using namespace std;

int main(){
    string jp;
    int dar, money=0 , dinheiro[];
    for(int j=0;j<4;j++){
        cin >> dinheiro[];
    }


 return 0;
}
