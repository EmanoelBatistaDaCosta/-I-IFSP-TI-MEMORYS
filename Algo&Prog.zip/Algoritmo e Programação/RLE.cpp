#include <iostream>

using namespace std;

int main(){
    int lizt=0,algo[17];

    for(int r=0;r<17;r++)
    {
        cin >> algo[r];
    }

    for(int l=0;l<17;l++)
    {
        cout << algo[l] << endl;
    }
    cout << algo << endl;

    return 0;
}
