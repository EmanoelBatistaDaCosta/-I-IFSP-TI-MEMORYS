#include <iostream>

using namespace std;

int main(){
    int n,i,choco;cin >> n >> i ;
    i=;
    choco = ;
    cout << choco << endl;

 return 0;
}
