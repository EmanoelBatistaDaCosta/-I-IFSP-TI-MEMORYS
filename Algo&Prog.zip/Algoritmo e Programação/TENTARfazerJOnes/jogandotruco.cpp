#include <iostream>

using namespace std;

int main(){
    int n=1; cin >> n;
    while( n <= 13)
   {
    cout << " " << endl;
    cout << n << endl;
    n+=1;
   }

    return 0;
}
