#include <iostream>


using namespace std;

int main(){
    int n;
    cin >> n;

    while(cin >> n)
    {
        if(n%2==0)
        {
        cout << "Numero. Par" << endl;
        }
        else
        {
         cout << "Numero. Impar" << endl;
        }

    }
 return 0;

}
