#include <bits/stdc++.h>

using namespace std;

int main(){
    vector <string> lista;

    lista.push_back("jones");
    cout << lista[0] << endl;


 return 0;
}
