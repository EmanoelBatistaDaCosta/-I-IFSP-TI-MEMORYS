#include <iostream>

using namespace std;

int main(){
    string cart[13];

    for(int e=0;e<13;e++){
        cin >> cart[e];
    }
    for(int y=0,v=0;y<52;y++){
        cout << cart[v] << endl;
        if(y%4==3){
            v=v+1;
        }

    }

    return 0;
}
