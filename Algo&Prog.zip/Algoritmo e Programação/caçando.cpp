#include<bits/stdc++.h>
#define pi 3.14159
using namespace std;
int main(){

long double a,b,c,d;
cin>>a;
b = pow(sin(75*3.141592/180),2);
c = pow (a,2)*b/(2*10);
cout<<round(c)<<"m"<<endl;








return 0;
}
