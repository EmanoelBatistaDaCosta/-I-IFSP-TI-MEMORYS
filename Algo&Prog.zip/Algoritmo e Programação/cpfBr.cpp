#include <iostream>
#include <cmath>
#include <iomanip>

using namespace std;

int main(){
   string a,b,cpf; cin >> a >> b;
   int cp = cpf.lenght();
   string =
;
