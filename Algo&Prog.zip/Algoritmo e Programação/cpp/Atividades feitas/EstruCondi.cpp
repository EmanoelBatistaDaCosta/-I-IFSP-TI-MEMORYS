#include <iostream>
#include <iomanip>
#include <cmath>

using namespace std;

int main(){
    float a,b,c,d,media; cin >> a >> b >> c >> d;
    media = a+b+c+d/4;
    if( media >= 7)
    {
        cout << "Aprovado";
    }
        else
        {
          cout << "Reprovado";
        }
}
