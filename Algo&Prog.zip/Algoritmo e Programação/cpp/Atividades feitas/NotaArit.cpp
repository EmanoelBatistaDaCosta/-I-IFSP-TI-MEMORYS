#include <iostream>
#include <iomanip>
#include <cmath>


using namespace std;

int main() {
    float a,b,mdarit; cin >> a >> b;
    mdarit = (a+b)/2;
    if(mdarit < 4)
    {
        cout << "Reprovado";
    }
    else
    {

        if(mdarit >= 4 && mdarit < 7)
        {
            cout << "Exame";
        }
        else
        {
            cout << "Aprovado";
        }
    }
}
