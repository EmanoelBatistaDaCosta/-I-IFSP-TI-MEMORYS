#include <iostream>
#include <algorithm>
#include <string>

using namespace std;

int main ()
{
    string so;
    cin >> so;
    transform(so.begin(), so.end(), so.begin(), ::toupper);

    bool a = so[0] == 'A' || so[1] == 'A' || so[2] == 'A' || so[3] == 'A' || so[4] == 'A';
    bool e = so[0] == 'E' || so[1] == 'E' || so[2] == 'E' || so[3] == 'E' || so[4] == 'E';
    bool i = so[0] == 'I' || so[1] == 'I' || so[2] == 'I' || so[3] == 'I' || so[4] == 'I';
    bool o = so[0] == 'O' || so[1] == 'O' || so[2] == 'O' || so[3] == 'O' || so[4] == 'O';
    bool u = so[0] == 'U' || so[1] == 'U' || so[2] == 'U' || so[3] == 'U' || so[4] == 'U';

    cout << "VOGAL A: " << a << endl;
    cout << "VOGAL E: " << e << endl;
    cout << "VOGAL I: " << i << endl;
    cout << "VOGAL O: " << o << endl;
    cout << "VOGAL U: " << u << endl;

}
