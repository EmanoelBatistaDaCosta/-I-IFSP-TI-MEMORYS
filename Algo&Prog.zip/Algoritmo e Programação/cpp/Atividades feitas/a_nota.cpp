#include <iostream>
using namespace std;

int main() {
    int A, M, N;
    cin >> A;
    cin >> M;
    N = M*2-A;
    cout << N << endl;
    return 0;
}
