#include <iostream>
#include <cmath>
#include <string>
#include <algorithm>

//---{ATIVIDADE 1}---//
using namespace std;

int main(){
            string a;
            getline(cin,a);
    //----------------------------------
    int rt = a.find("ando");
    //----------------------------------
    int ger = a.compare(a);
    //----------------------------------
    cout << rt << endl;
    //----------------------------------

}
