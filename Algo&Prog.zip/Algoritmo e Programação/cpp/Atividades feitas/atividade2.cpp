#include <iostream>
#include <cmath>
#include <string>
#include <algorithm>

//---{ATIVIDADE 2---//
using namespace std;

int main(){
            string at;
            getline(cin,at);
    //----------------------------------
    string at;
    getline(cin,at);
    //----------------------------------
    int rt = a.find("ando");
    string nov = b.replace("ANDO");
    //string nov = a.replace(rt,a.length(),a);
    //----------------------------------
    cout << nov << endl;
    //----------------------------------

}
