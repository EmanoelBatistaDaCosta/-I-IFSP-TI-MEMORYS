//______{aula JONES}________|
//_______{XIX/VII}________|
#include <iostream>
//------------------>
#include <cmath>
//------------------>
#include <string>
//------------------>
#include <algorithm>
//------------------>
using namespace std;
//------------------>

                int main(){
            //-------------//

    //----------------------------------//
    cout << hex << uppercase << 6a << endl;
    cout << hex << nouppercase << 2b << endl;
    //----------------------------------//
                return 0;
}
