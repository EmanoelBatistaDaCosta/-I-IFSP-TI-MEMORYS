#include <iostream>
#include <iomanip>
#include <cmath>

using namespace std;

int main()
{
    float a, quant;
    cin >> a;
    quant = pow(a,3);
    cout << fixed << setprecision (1) << quant << endl;
}
