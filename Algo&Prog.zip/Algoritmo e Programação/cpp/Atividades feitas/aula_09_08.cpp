#include <iostream>

using namespace std;

int main() {
    int id,sx;cin >> id >> sx;

    id >=18 ? (cout << "ja"):(cout << "nein"); sx =='m' ? (cout << "aprovado");

    return 0;
}
