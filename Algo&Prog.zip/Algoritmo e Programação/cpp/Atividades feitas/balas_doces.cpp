#include <iostream>

using namespace std;

int main ()
{
    int b, d, compradas;
    cin >> b;
    cin >> d;
    compradas = b+d;
    cout << compradas << endl;

}
