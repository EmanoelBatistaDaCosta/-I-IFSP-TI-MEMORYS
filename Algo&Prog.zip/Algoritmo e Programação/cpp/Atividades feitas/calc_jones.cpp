#include <iostream>
#include <iomanip>
#include <cmath>

using namespace std;

int main()
{
    float a, pi,calc;
    cin >> a;
    pi = 3,1415;
    calc = a*pi;
    cout << fixed << setprecision(2) << calc << endl;
}
