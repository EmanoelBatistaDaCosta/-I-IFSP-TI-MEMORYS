#include <iostream>
using namespace std;

int main() {
    int A, N, coems;
    cin >> A;
    cin >> N;
    coems = (A/(N+2))*2;
    cout << coems << endl;

    return 0;
}
