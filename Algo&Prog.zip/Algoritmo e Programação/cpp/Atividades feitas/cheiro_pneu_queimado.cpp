#include <iostream>
using namespace std;

int main() {
    int N, M, pressao;
    cin >> N;
    cin >> M;
    pressao = N-M;
    cout << pressao << endl;
    return 0;
}
