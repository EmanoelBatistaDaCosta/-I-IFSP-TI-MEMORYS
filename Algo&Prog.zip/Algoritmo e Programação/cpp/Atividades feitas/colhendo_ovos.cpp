#include <iostream>
#include <cmath>

using namespace std;

int main ()
{
    float N, ovos;
    cin >> N;
    ovos = N/12;
    cout << ceil(ovos) << endl;
}
