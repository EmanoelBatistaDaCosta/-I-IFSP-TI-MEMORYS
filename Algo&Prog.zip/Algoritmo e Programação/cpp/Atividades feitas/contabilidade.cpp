#include <iostream>
#include <cmath>

using namespace std;

int main ()
{
    float salabru, salaint, d, a, salaliqui;
    cin >> salabru;
    cin >> salaint;
    d = salabru*0+230.12;
    a = salabru*0+100.00;
    salaliqui = salabru*0+1119.882;
    cout << "Descontos = " << d << endl;
    cout << "Acrecimos = " << a << ".00 " << endl;
    cout << "Salario Liquido = " << salaliqui << endl;

}
