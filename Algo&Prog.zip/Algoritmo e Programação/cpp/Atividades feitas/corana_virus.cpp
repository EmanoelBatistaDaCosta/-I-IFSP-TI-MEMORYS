#include <iostream>
#include <iomanip>
#include <cmath>

using namespace std;

int main()
{
    long long a,b,c,soma;
    cin >> c;
    soma = pow(c,2);
    cout << soma << endl;
}
