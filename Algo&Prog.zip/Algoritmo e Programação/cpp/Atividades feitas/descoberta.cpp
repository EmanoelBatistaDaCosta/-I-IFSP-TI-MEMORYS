#include <iostream>

using namespace std;

int main()
{
    int a,t;
    cin >> a;
    t = a*4;
    cout << t << endl;

}
