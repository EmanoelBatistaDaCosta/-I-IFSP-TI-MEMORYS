#include <iostream>
#include <string>

using namespace std;

int main() {
    int id,tp;//cin >> id >> tp >> tatu >> fm >> bb >> jj;
    string  tatu,fm,bb,jj;
    cout << "informe sua idade:";
    cin >> id;
    cout << "informe se esta de gest��o:";
    cin >> tp;
    cout << "informe se e fumante (sim ou nao):";
    cin >> fm;
    cout << "informe se tem tatuagem (sim ou nao):";
    cin >> tatu;
    cout << "informe se ingeriu bebida alcoolica nas ultimas 24h:";
    cin >> bb;
    cout << "informe se esat de jejm no minimo de 10 horas (sim ou nao):";
    cin >> jj;
    if( (id >= 18 && <= 60) && (tp == "nao") && (fm == "nao") && (tatu == "nao") && (bb == "nao") && (jj == "sim")
        {
            cout << "aprovado para doa��o" << endl;
        }
    else
        {
            cout << "reprovado para doa��o" << endl;
        }
    return 0;
}
