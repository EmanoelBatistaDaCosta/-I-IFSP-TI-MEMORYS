#include <iostream>
#include <cmath>
#include <iomanip>

using namespace std;

int main ()
{
    long long x, y, z, n, L,m,o;
    cin >> x;
    cin >> y;
    cin >> z;
    cin >> n;
    L =(x+y+z)/n*n;
    cout << (x+y+z) << endl;
}
