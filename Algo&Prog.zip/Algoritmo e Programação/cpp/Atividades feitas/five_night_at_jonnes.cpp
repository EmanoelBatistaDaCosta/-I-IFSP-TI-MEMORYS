#include <iostream>
#include <iomanip>
#include <cmath>


using namespace std;

int main()
{
    long double a,b,f; //40_104.7=12//
    cin >> a >> b;
    f = floor(3.14 * pow(a/ 2,2)) / floor(b);
    cout << floor(f) << endl;

}
