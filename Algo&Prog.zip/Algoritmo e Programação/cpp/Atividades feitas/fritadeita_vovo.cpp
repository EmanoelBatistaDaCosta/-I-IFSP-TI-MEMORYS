#include <iostream>
using namespace std;

int main() {
    int C, F;
    cin >> C;
    F = (C*9/5)+32;
    cout << C << " graus celsius equivale a " << F << " graus fahrenheit " << endl;

    return 0;
}
