#include <iostream>
using namespace std;

int main() {
    int M, A, B, total;
    cin >> M;
    cin >> A;
    cin >> B;
    total = M-A-B;
    cout << total << endl;
    return 0;
}
