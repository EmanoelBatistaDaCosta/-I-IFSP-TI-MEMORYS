#include <iostream>
using namespace std;

int main() {
    int  A, M, D, ID;
    cin >> A;
    cin >> M;
    cin >> D;
    ID = A*365+M*30+D;
    cout << ID << endl;

    return 0;
}
