#include <iostream>
#include <algorithm>
#include <string>

using namespace std;

int main ()
{
    string pa, le;
    int x;
    cin >> pa >> le;
    transform(pa.begin(), pa.end(),pa.begin(), ::toupper);
    transform(le.begin(), le.end(),le.begin(), ::toupper);
    bool a = le[0] == pa[0];
    bool b = le[0] == pa[1];
    bool c = le[0] == pa[2];
    bool d = le[0] == pa[3];
    x = a+b+c+d;
    cout << x << endl;

}
