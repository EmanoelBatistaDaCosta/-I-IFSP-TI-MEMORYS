#include <iostream>
#include <iomanip>
#include <cmath>


using namespace std;

int main() {
    double nu1,nu2,men; cin >> nu1 >> nu2;
    men = fmin(nu1,nu2);
    cout << men << endl;
}
