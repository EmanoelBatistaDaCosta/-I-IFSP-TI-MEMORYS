#include <iostream>

using namespace std;

int main() {
    float n1,n2,md; cin >> n1 >> n2;
    md = (n1+n2)/2;

    if(md >= 6.0)
    {
        cout << "aprovado" << endl;
    }
    else
    {
        cout << "reprovado" << endl;
    }
    return 0;
}
