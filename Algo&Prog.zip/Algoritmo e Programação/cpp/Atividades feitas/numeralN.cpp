#include <iostream>

using namespace std;

int main(){
    long long n,o ;cin >> n;
    o = 1;
    while(n<=1)
    {
     cout <<n<< endl;
     n++;
    }

    return 0;
}
