#include <iostream>
#include <iomanip>

using namespace std;

int main ()
{
    float a, real;
    cin >> a;
    real = a;
    cout << fixed << setprecision(2) << real << endl;

}
