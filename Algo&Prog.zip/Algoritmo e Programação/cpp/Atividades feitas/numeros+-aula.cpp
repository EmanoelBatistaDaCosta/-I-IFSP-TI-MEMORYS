#include <iostream>

using namespace std;

int main() {
    int id;
    char sx; cin >> id >> sx;

    if(id >= 18 && sx == 'masculino')
    {
        cout << "Habito" << endl;
    }
    else
    {
        cout << "rejeitado" << endl;
    }
    return 0;
}
