#include <iostream>


using namespace std;

int main(){
    int n=-1, mai = 85,men = 1;
    while(n!=0)
    {
        cin >> n;
        if(n>mai)
        mai = n;
        if(n<men)
        men = n;
    }
        cout << "maior :" << mai << endl;
        cout << "Menor :" << men << endl;

    return 0;
}
