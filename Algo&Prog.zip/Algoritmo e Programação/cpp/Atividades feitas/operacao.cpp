#include <iostream>
#include <iomanip>
#include <cmath>
#include <algorithm>

using namespace std;

int main() {
    int nu1,nu2,esco; cin >> nu1 >> nu2 >> esco;
    if(esco == 1)
    {
        cout << "media" << (nu1+nu2)/2 << endl;
    }
    else if(esco == 2)
    {
        cout << fmax(nu1,nu2) - fmin(nu1,nu2) << endl;
    }
    else if(esco == 3)
    {
        cout << nu1*nu2 << endl;
    }
    else if(esco == 4)
    {
        cout << nu1/nu2 << endl;
    }
    else
    {
        cout << "Erro: O numero deve ser diferente de zero" << endl;
    }

}
