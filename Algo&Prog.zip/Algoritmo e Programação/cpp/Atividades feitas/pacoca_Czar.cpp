#include <iostream>
#include <iomanip>
#include <cmath>
#include <string>
#include <algorithm>

using namespace std;

int main() {
    string a,b;
    cin >> a >> b;
    a = a.substr(2, a.size()-1);
    b = b.substr(2, b.size()-1);
    double x,y;
    x = stod(a);
    y = stod(b);
    double g = y - x;
    g = g / 0.5;
    cout << floor(g) << endl;
}
