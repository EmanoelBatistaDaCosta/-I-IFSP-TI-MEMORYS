#include <iostream>
#include <string>

using namespace std;

int main ()
{
    string p;
    cin >> p;
    int pa = p.length();
    bool R = (p.substr(pa-1,1) == "S") || (p.substr(pa-1,1) == "s");
    cout << R << endl;
}
