#include <iostream>
#include <iomanip>
#include <cmath>


using namespace std;

int main()
{
    long double a,b,c,d, prd;
    cin >> a >> b >> c >> d;
    prd = (a* 60/ b) / (d/c);
    cout << round(prd) << endl;

}
