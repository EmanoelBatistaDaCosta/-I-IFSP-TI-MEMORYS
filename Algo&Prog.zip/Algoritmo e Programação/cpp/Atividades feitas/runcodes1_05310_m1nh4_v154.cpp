#include <iostream>

using namespace std;

int main() {
    int nt1,nt2,nt3;cin >> nt1 >> nt2 >> nt3;

       if(nt1 >=70 && nt2 >=75 && nt3 >=80)
       {
           cout << "aprovado" << endl;
       }
       else
       {
           cout << "reprovado" << endl;
       }
    return 0;
}
