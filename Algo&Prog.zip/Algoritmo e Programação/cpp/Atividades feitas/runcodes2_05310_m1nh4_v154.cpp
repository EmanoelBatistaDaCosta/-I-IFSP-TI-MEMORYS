#include <iostream>

using namespace std;

int main() {
    int ano;cin >> ano;

       if(ano >= )
       {
           cout << "ano bissexto" << endl;
       }
       else
       {
           cout << "nao bissexto" << endl;
       }
    return 0;
}
