#include <iostream>
#include <string>
#include <cmath>

using namespace std;

int main() {
    string s,c,i,p;getline(cin,s,c),i,p;

    i= 12 >= i <=99;
    p= 1.00 >= p <= 3.00;
     cout << << endl;
     cout << << endl;
}
