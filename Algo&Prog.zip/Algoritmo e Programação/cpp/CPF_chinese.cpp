#include <iostream>
#include <string>
#include <algorithm>

using namespace std;

int main (){
    string chi,cpf, enter,repla;
    getline(cin,chi);
    string part4 = chi.substr(14,3);
    string part3 = chi.substr(10,3);
    string part2 = chi.substr(6,3);
    string part1 = chi.substr(3,2);


    cout << part4 << "." << part3 << "." << part2 << "-" << part1 << endl;

}

//123.852.662-22
//string enterang = "CH&";//enter.replace(0,4,13,16);
