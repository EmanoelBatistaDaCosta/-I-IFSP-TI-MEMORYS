#include <iostream>
using namespace std;

int main() {
    int A, N;
    cin >> A;
    N = (A*2)/4;
    cout << N << endl;

    return 0;
}
