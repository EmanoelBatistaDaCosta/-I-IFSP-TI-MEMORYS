#include <iostream>
using namespace std;

int main() {
    int A, D, M;
    cin >> A;
    D = A*2;
    M = A/2;
    cout << D << "," << M << endl;

    return 0;
}
