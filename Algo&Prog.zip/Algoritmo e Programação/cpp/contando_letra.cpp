#include <iostream>
#include <string>
#include <algorithm>

using namespace std;

int main (){
    string pa; cin >> pa;
    int tm = pa.length();
    cout << tm << " letras" << endl;

}
