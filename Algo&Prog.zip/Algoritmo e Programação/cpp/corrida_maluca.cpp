#include <iostream>
using namespace std;

int main() {
    int P, N, T, C;
    cin >> C;
    cin >> N;
    C = (P*12)/N*22;
    cout << C << endl;

    return 0;
}
