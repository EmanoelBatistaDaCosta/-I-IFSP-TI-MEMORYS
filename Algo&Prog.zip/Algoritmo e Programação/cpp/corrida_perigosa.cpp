#include <iostream>
using namespace std;

int main() {
    int sentido, cautela;
    cin >> sentido;
    cautela = sentido/10;
    cout << cautela << endl;

    return 0;
}
