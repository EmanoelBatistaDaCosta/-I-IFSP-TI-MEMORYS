#include <iostream>
#include <string>

using namespace std;

int main(){
    //string entering = "@aluno.ifsp.edu.br";int a = entering.find("@aluno.ifsp.edu.br");
    string anter,s1,s2,s3,s4,s5;
    getline(cin,anter);
    string enter = "@aluno.ifsp.edu.br";
    string part = "";
    part = enter.substr(0,18);
    string s1 = "@aluno.ifsp.edu.br";
    string s2 = "@aluno.ifsp.edu.br";

    string s3 = "@aluno.ifsp.edu.br";
    string s4 = "@.ifsp.edu.br";

    string s5 = "@aluno.ifsp.edu.br";
    string s6 = "@aluno..edu.br";

    string s7 = "@aluno.ifsp.edu.br";
    string s8 = "@aluno.ifsp..br";

    string s9 = "@aluno.ifsp.edu.br";
    string s10 = "@aluno.ifsp.edu.";

    cout << "email valido: " << s1.compare(s2);
    cout << "email faltando aluno: " << s3.compare(s4) ;
    cout << "email faltando ifsp: " << s5.compare(s6) ;
    cout << "email faltando edu: " << s7.compare(s8) ;
    cout << "email faltando br: " << s9.compare(s10) ;

}
