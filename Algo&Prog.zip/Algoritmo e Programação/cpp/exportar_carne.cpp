#include <iostream>
using namespace std;

int main() {
    int n, m, a, l;
    cin >> n;
    cin >> m;
    cin >> a;
    l = n*m*a/4;
    cout << l << endl;

    return 0;
}
