#include <iostream>
#include <cmath>

using namespace std;

int main()
{
    long double x, y, a, b, c, px1, px2, px3, py1, py2, py3;
    cin >> x >> y;

    px1 = pow(3*x,2);
    py1 = pow(y,2);
    a = px1 + py1;

    px2 = 2*(pow(x,2));
    py2 = pow(5*y,2);
    b = px2 + py2;

    px3 = x*-100;
    py3 = pow(y,3);
    c = px3 + py3;

    if(a > b && a > c)
    {
        cout << "Rafael ganhou";
    }
    else
    {
        if(b > a && b > c)
        {
            cout << "Beto ganhou";
        }
        else
        {
            if(c > a && c > b)
            {
                cout << "Carlos ganhou";
            }
        }
    }

    return 0;
}
