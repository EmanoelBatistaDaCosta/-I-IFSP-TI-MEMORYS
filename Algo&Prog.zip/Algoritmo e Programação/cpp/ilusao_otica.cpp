#include <iostream>
using namespace std;

int main() {
    int A, B, L, C;
    cin >> A;
    cin >> B;
    L = A+B*2;
    C = B+A*2;
    cout << L << " vermelhos" << endl;
    cout << C << " pretos" << endl;

    return 0;
}
