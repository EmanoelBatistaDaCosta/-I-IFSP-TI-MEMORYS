#include <iostream>
#include <iomanip>

using namespace std;
int main ()
{
    float hr, salaliqui;
    cin >> hr;
    salaliqui = hr*3.1-9.0-6.0;
    cout << salaliqui << endl;

}
