#include <iostream>
#include <iomanip>
#include <cmath>

using namespace std;

int main() {
    int a,b,desc; cin >> a >> b;
    float c,desc2; cin >> c;

    if (1<=a<=120 && 0<=b<=5 && b*2+a)
    {
     cout << setprecision(desc) << ".00" << endl;
     cout << setprecision(desc2) << ".00%" << endl;

    }


}
