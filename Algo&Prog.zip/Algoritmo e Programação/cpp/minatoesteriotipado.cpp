#include <iostream>

using namespace std;

int main() {
    string a1,b1; cin >> a1 >> b1 ;

    if( a1 == "pedra" & b1 == "pedra" )
     {
         cout << "Empate";
     }
     else
     {
        cout << ;
     }
        if( a1 == "papel" & b1 == "papel")
            {
                cout << "Empate";
            }
        else
            {
                cout << ;
            }

            if( a1 == "tesoura" & b1 == "tesoura")
                {
                  cout << "Empate";
                }
            else
                {
                cout << ;
                }
                if( a1 == "pedra" & b1 == "tesoura")
                {
                 cout << ;
                }
                    else
                    {
                        cout << "Jogador 1";
                    }
                    if( a1 == "pedra" & b1 == "papel")
                    {
                        cout <
                    }
                        else
                        {
                            cout << "Jogador 2";
                        }
                        if( a1 == "tesoura" & b1 "pedra")
                        {
                            else
                            {
                                cout << "Jogador 2";
                            }
                            if( a1 == "tesoura" & b1 "papel")
                            {
                               else
                               {
                                   cout << "Jogador 1";
                               }
                               if( a1 == "papel" & b1 "pedra")
                               {
                                   else
                                   {
                                       cout << "Jogador 1";
                                   }
                                   if( a1 == "papel" & b1 "tesoura")
                                   {
                                       else
                                       {
                                           cout << "Jogador 2";

    return 0;
}
