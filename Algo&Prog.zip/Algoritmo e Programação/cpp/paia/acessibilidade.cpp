#include <iostream>
#include <iomanip>
#include <algorithm>

using namespace std;

int main(){
   float l,h,c,altura; cin >> i >> c >> l;
    if( i == h*100/c)
    {
       cout << "PROJETO SIMPLES" << endl;
    }
    if()
    {
        cout << "PROJETO ESPECIAL"
    }
}
return 0;
