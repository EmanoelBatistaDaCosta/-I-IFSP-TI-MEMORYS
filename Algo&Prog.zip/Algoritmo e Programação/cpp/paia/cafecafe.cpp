#include <iostream>
#include <iomanip>


using namespace std;

int main(){
    int a,b,cafe; cin >> a >> b;
    if()
    {

    }
    if()
    {

    }

}
return 0;
