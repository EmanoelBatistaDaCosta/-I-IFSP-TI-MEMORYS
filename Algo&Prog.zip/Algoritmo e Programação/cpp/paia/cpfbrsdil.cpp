#include <iostream>
#include <string>

using namespace std;

int main( {
    string cfp; cin >> cpf ;
    int cf = cpf.lenght();
    string pf = cpf.substr(3,1);
    string = cpf.substr(4,1);
    string = cpf.substr(7,1);


}
