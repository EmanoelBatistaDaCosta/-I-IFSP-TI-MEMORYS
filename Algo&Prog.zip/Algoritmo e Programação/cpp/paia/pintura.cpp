#include <iostream>


using namespace std;

int main(){
    int a,b,pintura; cin >> a >> b;
    if(a < 40 && b < 10 == a*b)
    {
        cout <<  << endl;
    }
    if( 3 < a < 160 && -1 < c < 100 == a+b)
    {
        cout <<  << endl;
    }

return 0;
}
