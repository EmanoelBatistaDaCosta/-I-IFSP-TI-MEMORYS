#include <iostream>

using namespace std;

int main () {
    int a,b,c,d,e,f; cin >> a >> b >> c >> d >> e >> f;

    if(d >= a && b <= e && f >= c)
    {
       cout << "SIM" << endl;
    }


}
