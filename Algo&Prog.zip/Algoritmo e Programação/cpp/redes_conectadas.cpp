#include <iostream>
using namespace std;

int main() {
    int N, conect;
    cin >> N;
    conect = N*2-1;
    cout << N << endl;

    return 0;
}
