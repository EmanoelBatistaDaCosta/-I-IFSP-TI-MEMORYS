#include <iostream>
using namespace std;

int main()
{
    float e = 1.2;
    cin >> e;
    cout << fixed << setprecision(2) << e << endl;
    return 0;
}
