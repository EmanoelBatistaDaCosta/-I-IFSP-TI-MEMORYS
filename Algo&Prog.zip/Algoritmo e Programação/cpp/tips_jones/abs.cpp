#include <iostream>
#include <iomanip>
#include <cmath>

using namespace std;

int main()
{
    double a,b,c,d,R;
    a = 1;
    b = 2;
    R = a-b;
    d = abs(R);
    cout << R << endl;
}
