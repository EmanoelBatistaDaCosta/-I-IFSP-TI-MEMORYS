#include <iostream>
#include <iomanip>
#include <cmath>
#include <string>


using namespace std;

int main()
{
    string num1, num2;
    cin >> num1;
    cin >> num2;
    string num1 = "1";
    string num2 = "2";
    string R = num1 + " " + num2;
    cout << stoi(num1) + stoi (num2) << endl;
}
