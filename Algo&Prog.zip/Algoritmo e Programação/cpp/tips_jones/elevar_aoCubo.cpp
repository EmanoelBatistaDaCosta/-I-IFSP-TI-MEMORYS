#include <iostream>3
#include <iomanip>
#include <cmath>

using namespace std;

int main()
{
    double N,R;
    cin >> N;
    R = pow(N, 1.0/4.0);
    cout << R << endl;
}
