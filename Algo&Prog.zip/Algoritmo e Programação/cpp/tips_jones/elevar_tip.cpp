#include <iostream>
#include <iomanip>
#include <cmath>

using namespace std;

int main()
{
    double bas,expo,R;
    cin >> bas >> expo;
    R = pow(bas,expo);
    cout << R << endl;
}
