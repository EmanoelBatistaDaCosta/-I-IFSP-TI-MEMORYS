#include <iostream>
#include <iomanip>
#include <cmath>
#include <locale>
#include <string>


using namespace std;

int main()
{
    string palavra;
    getline(cin,palavra);

    cout << "minha palavra = " << palavra << endl;
	int tamanho = palavra.length();
    cout << "quantidade = " << tamanho << endl;

}
