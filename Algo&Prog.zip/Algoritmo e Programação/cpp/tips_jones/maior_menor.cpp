#include <iostream>
#include <iomanip>
#include <cmath>

using namespace std;

int main()
{
    double a,b,c,d,R;
    a = 10;
    b = 20;
    c = 30;
    d = 40;
    R = fmax(fmax(fmax(a,b),c),d) ;
    cout << R << endl;
}
