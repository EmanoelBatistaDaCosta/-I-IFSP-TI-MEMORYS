#include <iostream>
#include <iomanip>
#include <cmath>
#include <string>
#include <algorithm>

using namespace std;

int main() {
    string a,b;
    cin >> a >> b;
    a = a.substr(2, a.size()-1);
    b = b.substr(2, b.size()-1); // remove os dois primeiros caracteres da string (R$)
    double x,y;
    x = stod(a);
    y = stod(b); // transforma a string em double
    double g = y - x; // calcula o lucro total
    g = g / 0.5; // divide o lucro pelo preco da pacoca
    cout << floor(g) << endl;
}
