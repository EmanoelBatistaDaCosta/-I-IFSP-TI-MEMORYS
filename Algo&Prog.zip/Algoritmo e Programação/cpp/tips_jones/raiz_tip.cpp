#include <iostream>
#include <iomanip>
#include <cmath>

using namespace std;

int main()
{
    double N,R;
    cin >> N;
    R = sqrt(N);
    cout << R << endl;
}
