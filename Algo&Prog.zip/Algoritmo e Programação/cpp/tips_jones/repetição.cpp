#include <iostream>


using namespace std;

int main(){
    int senha = 2002;
    cin >> senha;

    while(senha != 2002)
    {
        cout << "Senha incorreta" << endl;
        cin >> senha;
    }
    cout << "Acesso permitido" << endl;

 return 0;
}
