#include <iostream>
#include <iomanip>
#include <cmath>
#include <string>


using namespace std;

int main()
{
    string num1, num2, num0;
    cin >> num1;
    cin >> num2;
    cin >> num0;
    int n0 = stoi(num0);
    float n1 = stof(num1);
    float n2 = stof(num2);
    cout << n0+n1/n2 << endl;
}
