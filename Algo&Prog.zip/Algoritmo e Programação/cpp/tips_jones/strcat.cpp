#include <iostream>
#include <iomanip>
#include <cmath>
#include <string.h>
#include <string>


using namespace std;

int main()
{
    string palavra;
    getline(cin,palavra);
    cout << "minha palavra = " << palavra << endl;

    int tamanho = palavra.length();
    cout << "qtde caracteres = " << tamanho << endl;

    cout << "segunda letra da minha palavra = " << palavra.at(5) << endl;

    string a = "ifsp � ";
    string b = "palmeiras";
    string c = strcat(a,b);
    cout << c << endl;
}
