#include <iostream>
#include <iomanip>
#include <cmath>
#include <locale>
#include <string>


using namespace std;

int main()
{
    string palavra;
    cin >> palavra;

    cout << "minha palavra = " << palavra << endl;

}
