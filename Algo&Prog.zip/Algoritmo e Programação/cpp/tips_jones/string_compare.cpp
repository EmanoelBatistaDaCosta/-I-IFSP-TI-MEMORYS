#include <iostream>
#include <cmath>
#include <string>
#include <algorithm>


using namespace std;

int main()
{
        string entra1 = "BRANCO";
        string entra2 = "PRETO";
    //----------------------------------
    int rt = entra1.compare(entra2);
    //----------------------------------

    //----------------------------------
    cout << rt << endl;
    //----------------------------------

}
