#include <iostream>
#include <cmath>
#include <string>
#include <algorithm>


using namespace std;

int main()
{
    string a = "ICH MAG SCHUHE IN IFSP";
    int rt = a.find("SCHUHE");
    cout << rt << endl;


}
