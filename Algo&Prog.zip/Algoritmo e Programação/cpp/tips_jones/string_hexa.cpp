//______{hex & oct}________
//_______{TIP}________
#include <iostream>
//------------------
#include <cmath>
//------------------
#include <string>
//------------------
#include <algorithm>
//------------------
using namespace std;
//------------------
            int main(){
        //--------------//
            int dc = 14;
    //-----------------------//
    cout << hex << dc << endl;
    cout << oct << dc << endl;
    //-----------------------//
            return 0;
}
