#include <iostream>
#include <cmath>
#include <string>
#include <algorithm>


using namespace std;

int main()
{
    string a = "ICH MAG SCHUHE IN IFSP";
    string nv;
    getline(cin,nv);
    string at;
    getline(cin,at);
    int p = a.find(at);

    string nov = a.replace(p,nv.length(),nv);
    cout << nov << endl;


}
