//______{tabela TOTAL}________|
//_______{TIP}________|
#include <iostream>
//------------------>
#include <cmath>
//------------------>
#include <string>
//------------------>
#include <algorithm>
//------------------>
using namespace std;
//------------------>

            int main(){
        //-------------//
            int a = 10;
            char res [50];
    //----------------------//
            itoa (a,res,2);
    //----------------------//

    //----------------------------------//
    cout << "hexadecimal " << hex << a << endl;
    cout << "decimal " << dec << a << endl;
    cout << "octal " << oct << a << endl;
    cout << "binario " << res << endl;
    //----------------------------------//
                return 0;
}
