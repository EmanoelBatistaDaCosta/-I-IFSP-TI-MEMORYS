#include <iostream>
#include <iomanip>
#include <cmath>
#include <string>
#include <algorithm>


using namespace std;

int main()
{
    string p,b;
    getline(cin,p);
    string part1 = p.substr(0,4);
    string part2 = p.substr(5,8);
    cout << "que escola?: " << part1 << endl;
    cout << "de onde: " << part2 << endl;
}
