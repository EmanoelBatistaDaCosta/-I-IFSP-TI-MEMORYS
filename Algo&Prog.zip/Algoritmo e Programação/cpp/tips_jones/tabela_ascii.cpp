#include <iostream>
#include <iomanip>
#include <cmath>
#include <string>
#include <string.h>


using namespace std;

int main()
{
    string pala;
    getline(cin,pala);
    int c = (int) pala[0];
    c = c+32;
    char conv = c;
    cout << conv << endl;

}
