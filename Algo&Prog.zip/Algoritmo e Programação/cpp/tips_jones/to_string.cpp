#include <iostream>
#include <iomanip>
#include <cmath>
#include <string>


using namespace std;

int main()
{
    string num1, num2, R;
    cin >> num1;
    cin >> num2;
    string R = to_string (a);
    string R = to_string (b);
    cout << R << endl;
}
