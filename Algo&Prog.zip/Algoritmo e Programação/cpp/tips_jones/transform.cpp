#include <iostream>
#include <iomanip>
#include <cmath>
#include <string>
#include <algorithm>


using namespace std;

int main()
{
    string entrada = "Hello World";
    transform(entrada.begin(), entrada.end(),entrada.begin(), ::tolower);;
    cout << entrada << endl;
    transform(entrada.begin(), entrada.end(),entrada.begin(), ::toupper);;
    cout << entrada << endl;
}
