#include <bits/stdc++.h>
#include <fstream>

using namespace std;

int main(){
        string ln,nome;
        getline(cin,nome);
    ifstream arquivo;
   arquivo.open("nomes.txt",ios::in);

   while(! arquivo.eof())
   {
       getline(arquivo,ln);
       cout << ln << endl;
       if(ln==nome){
        cout << "Encontrado com sucesso" << endl;
       }else{
       cout << "Este nome nao foi encontrado na lista" << endl;
       }

   }

    return 0;
}
