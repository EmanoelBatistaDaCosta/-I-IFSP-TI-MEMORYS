#include<iostream>

suing namespace std;

int main(){
cout <<"O";
}
