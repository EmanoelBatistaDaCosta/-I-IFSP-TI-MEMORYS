#include <bits/stdc++.h>
#include <fstream>

using namespace std;

int main(){
    ofstream arquivo;
    arquivo.open("Arquivo.txt",ios::app);

    string nm;

    while(cin >> nm){
        arquivo << nm << endl;
    }

    arquivo.close();

    return 0;

}
