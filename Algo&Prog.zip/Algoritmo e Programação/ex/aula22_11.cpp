#include <bits/stdc++.h>
#include <fstream>

using namespace std;

int main(){
    string ln;
    ifstream arquivo;
   arquivo.open("Arquivo.txt",ios::in);

   while(! arquivo.eof())
   {
       getline(arquivo,ln);
       cout << ln << endl;
       if(ln=="Duken"){
        cout << "foi encontrado com sucesso :)" << endl;
       }else{
       cout << "nao foi encontrado :(" << endl;
       }

   }


    return 0;

}
