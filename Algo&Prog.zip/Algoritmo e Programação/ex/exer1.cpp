#include <bits/stdc++.h>
#include <fstream>

using namespace std;

int main(){
    int op

    do{
        cout <<
        cin >>

    }
    switch(op)
    case 1: fstream arquivo;
            arquivo.open("agenda.txt",ios::app);
            string nome,telefone,email;
            cin >> nome >> telefone >> email;
            arquivo << nome << endl;
            arquivo << telefone << endl;
            arquivo << email << endl;
            arquico.close();
            break;
    case 2: ifstream arquivo;
            arquivo.open("agenda2.txt",ios::in);
            string nome2,telefone2,email2;
            cin >>

    return 0;
}
