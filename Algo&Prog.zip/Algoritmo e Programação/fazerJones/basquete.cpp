#include <iostream>
#include <string>

using namespace std;

int main(){
    int tim,t,k; cin >> tim,t,
    string time; cin >> time;
    substr(1,2)


    cout << << endl;
    return 0;
}
