 #include <iostream>

 using namespace std;
 int main(){

    int na=3;
    int x,y,mult;cin >> x >> y;
    mult = x*y;
    while( na < 10)
    {
        cout << na << endl;
        na++;
    }

    return 0;
}
