#include <iostream>

using namespace std;

int main(){
    int N, M;cin >> N >> M;

    if (N % 3 != 0) {
        N++;
    }

    for (int i = N; i <= M; i += 3) {
        cout << i << endl;
    }

    return 0;
}
