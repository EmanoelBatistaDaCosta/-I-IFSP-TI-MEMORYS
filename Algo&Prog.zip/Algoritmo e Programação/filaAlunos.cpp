#include <bits/stdc++.h>

using namespace std;

int main(){
    int al;
    vector <float> alu;cin >> al;

    alu.push_back(0);
    alu.push_back(1);
    alu.push_back(2);
    alu.push_back(3);
    alu.push_back(4);
    alu.push_back(5);
    alu.push_back(6);

    sort(alu.begin(),alu.end(),greater<>());
    for(int t;t<7;t++){
       cout << alu[t] << endl;
    }
    return 0;
}

