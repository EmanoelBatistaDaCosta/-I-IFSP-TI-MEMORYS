#include <iostream>

using namespace std;

int main(){
   int grid=0, largada[17];
   for(int a=0;a<17;a++)
   {
        cin >> largada[a];
   }
   for(int y=0;y<17;y++)
   {
       cout << largada[y] << endl;
   if( y>=2)
   {
       cout << grid << endl;
   }

   }

 return 0;
}
