#include <iostream>

using namespace std;

int main(){
    int id=1; cin >> id;
    while(id < 10)
    {
        id++;
        cout << id << endl;
        if(id>=18)
        {
            cout << id+10 << endl;
        }

    }

    return 0;
}
