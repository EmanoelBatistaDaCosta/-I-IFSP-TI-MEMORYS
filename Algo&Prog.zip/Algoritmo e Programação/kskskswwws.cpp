#include <iostream>

using namespace std;

int main(){
   int  loteria=0,teria[6];
    for(int g=0;g<6;g++)
    {
        cin >> teria[g]
    }
    for(int b=0;b<6;b++)
    {
        cout << teria[b] << endl;
    }


 return 0;
}
