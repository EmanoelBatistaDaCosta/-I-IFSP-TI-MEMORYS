#include <iostream>

using namespace std;

int main(){
    int cinco[5], lista=0;

    for(int a=0;a<5;a++){
    lista = cinco[a];
    cout << lista*cinco[a] << endl;
    }
    cout << lista << endl;

    return 0;
}
