#include <bits/stdc++.h>

using namespace std;

int main(){

    int kkk=0,lista[0];
    for(int n=0;n<100;n++){
        cin >> lista[n];
    }
    for(int y=0;y<100;y++){
     cout << lista[y] << endl;
    }


 return 0;
}
