#include <iostream>

using namespace std;

int main(){
    int pcc=1,cinc=0,cv[5];
    for(int c=0;c<5;c++){
        cin >> cv[c];
        pcc= pcc*cv[c];
    }
    for(int v=0;v<5;v++){
        cout << cv[v]<< endl;
    }
    cout << pcc << endl;
 return 0;
}
