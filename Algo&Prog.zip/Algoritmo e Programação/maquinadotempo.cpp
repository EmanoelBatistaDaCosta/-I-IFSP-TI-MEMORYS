#include <iostream>


using namespace std;

int main() {
    int a,b,c; cin >> a >> b >> c;

    if(a-c == 0 || c-a == 0 || a-b == 0 || b-a == 0 || c-b == 0 || b-c == 0 || a-b-c == 0 || b-c-a == 0 || c-a-b == 0 || b-a-c == 0 || c-b-a == 0)
    {
        cout << "S" << endl;
    }
    else
    {
        cout << "N" << endl;
    }

}
