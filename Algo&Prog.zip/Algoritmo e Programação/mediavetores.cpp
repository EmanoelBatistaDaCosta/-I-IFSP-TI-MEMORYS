#include <iostream>
#include <iomanip>

using namespace std;

int main (){
    int c,n, sum=0;int cont=0;cin >> c;

    double perc;
    for(int i=0; i<c;i++){

        cin >> n;
        int alu[n];
        for(int j=0;j < n; j++){

            cin >> alu[j];
            sum += alu[j];
        }
        float med = (float)sum/ (float)n;
        for(int i=0; i < n; i++){

        if(alu[i] > med ){

            cont++;
            }
        }

         perc = (double) (100*cont) / n;
        cout << fixed << setprecision(3) << perc << "%" << endl;

        cont=0;
        sum=0;
        perc=0;
    }

    return 0;
}
//(float) isto � chamado de casting
