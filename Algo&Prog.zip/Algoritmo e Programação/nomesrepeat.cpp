#include <iostream>


using namespace std;

int main(){
    string nom ;

    while(getline(cin,nom))
    {
        cout << nom + "s" << endl;
    }
 return 0;

}
