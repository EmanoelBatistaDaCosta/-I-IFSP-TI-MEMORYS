#include <iostream>


using namespace std;

int main (){
    int numeros[10];
    int cont=0;

    for(int i=0; i < 10; i++){
        cin >> numeros[i];
        if(numeros[i]%2==1)
            cont++;
    }
    int aux = 0;
    int impares[cont];
    int mult = 1;

    for(int i=0; i < 10; i++) {
        if(numeros[i]%2==1){
            impares[aux] = numeros[i];
         mult = mult*impares[aux];
        aux++;
        }
    }

    for(int i =0; i <cont; i++){
        cout << impares[i] << " ";
    }
    cout << "multiplicacao = " << mult << endl;

    return 0;
}
