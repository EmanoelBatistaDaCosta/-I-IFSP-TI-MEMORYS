#include <iostream>

using namespace std;

int main(){
    int a=1, b=2000;

    while(a < 1000)
    {
        a++;
        cout << a << endl;
        if( a%11 == 0 )
        {
            cout << 5 << endl;
        }

    }

    return 0;
}
