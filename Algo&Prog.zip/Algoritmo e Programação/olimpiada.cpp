#include <iostream>


using namespace std;

int main() {
    int


    cout << << endl;
}
