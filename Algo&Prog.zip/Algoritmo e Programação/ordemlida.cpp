#include <iostream>

using namespace std;
int main(){
 int a,b,c,d,e=1; cin >> a >> b >> c >> d;
    while( e >= 5)
    {
        e++;
        cout << a << b << c << d << endl;
        if( e == a,b,c,d)
        {
            cout << e << endl;
        }
    }

 return 0;
}
