#include <iostream>


using namespace std;

int main(){
    int pat,aux; cin >> pat;
    aux = pat;

    while(pat >= 1)
    {
        cout << pat << " Patinhos foram passear, alem das montanhas para brincar" << endl;
        pat--;
        cout << "A mamae gritou quack quack quack quack, mas so " << pat-1 << " patinhos voltaram de la"<< endl;
    }
    if(pat==1)
    {
        cout << "A mamae patinha foi procurar, alem das montanhas, na beira do mar" << endl;
    }
    else
    {
     cout <<  "A mamae gritou quack quack quack quack, mas nenhum patinho voltou de la"<< endl;
    }
    if(aux==1)
    {
        cout << "A mamae gritou quack quack quack quack, e os" << aux << " patinhos voltaram de la" << endl;
    }

    return 0;
}
