#include <iostream>


using namespace std;

int main(){
    int pat,aux; cin >> pat;
    aux = pat;

    while(pat >= 1)
    {
        cout << pat << " Patinhos foram passear alem das montanhas para brincar" << endl;
        pat--;
        cout << "A mamae gritou 'quack quack quack quack' mas so " << pat-1 << " patinhos voltaram de la..."<< endl;
    if(pat==1)
    {
     cout <<  "A mamae gritou 'quack quack quack quack' mas so " << pat << " patinho voltou de la..."<< endl;
    }
    if(pat==0)
    {
     cout <<  "A mamae gritou 'quack quack quack quack' mas nenhum patinho voltou de la;"<< endl;
    }

    }

    cout << "Final ruim" << " Atualizando Final bom..." << endl;

    if(aux==1)
    {
    cout << "A mamae gritou 'quack quack quack quack' mas 1 patinho voltou de la..." << endl;
    }
    else
        {
        cout << "A mamae gritou 'quack quack quack quack' mas " << aux << " voltaram de la." << endl;
    }

    return 0;
}
