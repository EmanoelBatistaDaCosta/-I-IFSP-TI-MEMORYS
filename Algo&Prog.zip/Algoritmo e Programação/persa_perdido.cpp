#include <bits/stdc++.h>

using namespace std;

int main(){
    vector <int> persa;

    persa.push_back(0);
    persa.push_back(2);
    persa.push_back(3);



    return 0;
 }
