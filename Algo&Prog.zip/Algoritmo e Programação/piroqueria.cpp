#include <iostream>


using namespace std;

int main() {
    int e1,e2,e3,pipoca,ida; cin >> e1 >> e2 >> e3;

    if( ida == 1 && e1+e2+e3 )
    {

    }

    cout << pipoca << endl;

}
