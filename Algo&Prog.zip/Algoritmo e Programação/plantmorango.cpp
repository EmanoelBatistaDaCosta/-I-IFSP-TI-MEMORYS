#include <iostream>
#include <cmath>
#include <iomanip>

using namespace std;

int main(){
   int cm,mt,lg,lg2,ar1,ar2; cin >> cm >> mt >> lg >> lg2;
    ar1 = cm*mt;
    ar2 = lg*lg2;
    cout << fmax(ar1,ar2) << endl;
   return 0;
}
