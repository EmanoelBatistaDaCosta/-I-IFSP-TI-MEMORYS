#include<bits/stdc++.h>
using namespace std;
int main(){
string a,DDD,XXXX,YYYY;
cin>>a;
DDD = a.substr(0,2);
XXXX = a.substr(2,4);
YYYY = a.substr(6,4);
cout<<"+55"<<"("<<DDD<<")"<<XXXX<<"-"<<YYYY<<endl;





return 0;
}
