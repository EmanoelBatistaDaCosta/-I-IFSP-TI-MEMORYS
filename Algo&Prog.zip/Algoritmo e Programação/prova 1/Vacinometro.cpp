#include <iostream>
#include <iomanip>

using namespace std;

int main ()
{
    float n, v, vacidade;
    cin >> n;
    cin >> v;
    vacidade = n-v/2;
    cout << fixed << setprecision(1) << vacidade << "%" << endl;

}
