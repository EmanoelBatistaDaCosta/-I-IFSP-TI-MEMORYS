#include <iostream>
#include <iomanip>

using namespace std;

int main ()
{
    float s , velocidade;
    cin >> s;
    velocidade = s/2+(3)-10.00;
    cout << fixed << setprecision(2) << velocidade << endl;

}
