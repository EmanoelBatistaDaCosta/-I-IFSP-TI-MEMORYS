#include <iostream>

using namespace std;

int main()
{
    int H, h, m, s, t, atual_1, atual_2 ,atual_3;
    cin >> h;
    cin >> m;
    cin >> s;
    cin >> t;
    h = 2;
    atual_1 = h+t;
    atual_2 = s+t;
    cout << atual_1 << endl;
    cout << m << endl;
    cout << atual_2 << endl;
}
