#include <iostream>

using namespace std;

int main()
{
    int H, h, m, s, t, atual_1, atual_2 ,atual_3;
    cin >> h;
    cin >> m;
    cin >> s;
    cin >> t;
    h = 11;
    m = 0;
    s = 0;

    atual_1 = h+t;
    cout << atual_1 << endl;
    cout << m << endl;
    cout << s << endl;
}
