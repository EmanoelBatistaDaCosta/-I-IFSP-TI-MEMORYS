#include<bits/stdc++.h>
using namespace std;
int main(){
    int g,h,i,f,p,k;
    string entrada,dis,d,m,ano,hr,minu,mb,seg,seg2,ascii,asci,asc,as ;
    getline(cin,entrada);
dis = entrada.substr(27,5);
d = entrada.substr(46,2);
m = entrada.substr(49,1);
ano = entrada.substr(51,12);
hr = entrada.substr(73,2);
minu = entrada.substr(81,1);
mb = entrada.substr(83,1);
seg = entrada.substr(91,2);
seg2 = entrada.substr(94,2);
int Q1=entrada.find(") ao");
int Q2=entrada.find(", usando");
string Q3=entrada.substr(Q1, Q2-Q1);
double a = stod(dis);
g = ceil(a);
int b = stoi(d,0,16);
int c = stoi(m,0,16);
int an = stoi(ano,0,2);
int hrt = stoi(hr);
h = sqrt(hrt);
int minut = stoi(minu);
int mb2 = stoi(mb);
i = pow(minut,mb2);
int ks = stoi(seg);
int ksk = stoi(seg2);
f = fmin(ks,ksk);
cout<<"Caro Major Xyko, faca "<<ceil(a)<<" disparos em "<<b<<"/"<<c<<"/"<<an<<", as "<<hrt<<":"<<i<<":"<<f<<" ao"<<Q3<<", usando "<<endl;
//cout<<g<<endl<<b<<endl<<c<<endl<<an<<endl<<h<<endl<<minu<<endl<<i<<endl<<seg<<endl<<seg2<<endl<<f<<endl;
return 0;
}
