#include <bits/stdc++.h>

using namespace std;

int main(){
    vector <int> vetor;

    vetor.push_back(5);
    vetor.push_back(4);
    vetor.push_back(3);
    vetor.push_back(2);
    vetor.push_back(1);
    vetor.push_back(0);

    sort(vetor.begin(),vetor.end());
    for(int r=0;r<vetor.size();r++){
        cout << vetor[r] << " ";
    }

 return 0;
}
