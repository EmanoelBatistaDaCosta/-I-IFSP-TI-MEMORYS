#include <iostream>

using namespace std;

int main(){
    int a=1,b,c; cin >> a >> b >> c;
    while()
    {


    if()
    {

    }

    }

 return 0;
}
