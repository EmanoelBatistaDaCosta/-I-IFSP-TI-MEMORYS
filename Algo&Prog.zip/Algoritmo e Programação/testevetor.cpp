#include <iostream>


using namespace std;

int main (){
    string nome[5];

    for(int i=0; i < 5; i++){
        cin >> nome[i];
    }

    for(int i=0; i < 5; i++){
            if(nome[i]=="Fernanda")
        cout << "Fernanda esta na 4� posi��o"  << i+1 << endl;
    cout << nome[i] << endl;
    }

    return 0;
}
